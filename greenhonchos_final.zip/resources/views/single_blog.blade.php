@extends('layout.app')
@section('content')
@include('layout.navbar')
<!--============ Blog ============-->
<div class=" mb-3" style="margin-top:20px;">
		  <img class="card-img-top" src="{{asset('uploads')}}/{{$single_blog->image}}" alt="Card image cap" style="height:300px;width:60%;">
		  <div class="card-body">
			<h5 class="card-title">{{$single_blog->title}}</h5>
			<p class="card-text">
                {{$single_blog->content}}
			</p>
			<p class="card-text"><small class="text-muted">{{date('d F, Y', strtotime($single_blog->created_at))}}</small></p>
		  </div>

          <!--comment section-->
            <div class="card">
                <div class="card-header">
                    Comments
                </div>
                <div class="card-body">
                    @foreach($comments as $comment)
                        <b>Name:{{$comment->name}}</b>
                        <p>{{$comment->comment}}</p>
                    @endforeach
                </div>
            </div><br>
            <div class="card" style="width:50%;">
            <div class="card-header">
                Leave comment
            </div>
            <div class="card-body">
            <form method="post" action="{{url('comment')}}">
                @csrf
                <input type="hidden" name="blog_id" value="{{$single_blog->id}}">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp" placeholder="Enter name">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <textarea name="comment" class="form-control" placeholder="comment"></textarea>
                        </div>
                    </div>
                    
                </div>
                <button type="submit" class="btn btn-primary form-control" style="width:20%;">Submit</button>
                </form>
            </div>
            
            </div>
          <!--\comment section-->
</div>
<!--============ /Blog ============-->
@endsection