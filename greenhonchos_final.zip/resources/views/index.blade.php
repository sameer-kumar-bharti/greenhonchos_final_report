@extends('layout.app')

@section('content')
@include('layout.navbar')
<!--main content-->

<div style="margin-top:20px;">
<h5>Blogs</h5><br>
    <div class="row">
        @foreach($all_blogs as $blog)
        <div class="col-md-4">
            <div class="card bg-light mb-3">
                <div class="card-body">
                <h5 class="card-title"><a href="{{url('single_blog',$blog->slug)}}">{{$blog->title}}</a></h5>
                <p class="card-text">{{Str::limit($blog->content, 50)}}...</p>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
<!--\main content-->
@endsection