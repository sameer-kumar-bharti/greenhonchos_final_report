

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container" style="margin-top:40px;">
<div class="row">
	
	<div class="col-md-4">
	<form action="<?php echo e(url('dashboard')); ?>" method="get">
		<select class="form-control" name="filter">
			<option value="">Author</option>
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
	<span><button class="btn btn-primary float-right" type="submit">Search</button></span>
</form>
	<div class="col">
		<a class="btn btn-primary float-right" href="<?php echo e(url('blog')); ?>">Add blog</a>
	</div>
</div><br><br>
	
	<table class="table">
	  <thead class="thead-dark">
		<tr>
		  <th scope="col">#</th>
		  <th scope="col">Title</th>
		  <th scope="col">Content</th>
		  <th scope="col">Image</th>
		  <th scope="col" style="width:16%;">Action</th>
		</tr>
	  </thead>
	  <tbody>
		<?php
        $i = 0;
		?>
		<?php if(count($blogs) > 0): ?>
			<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
			<th scope="row"><?php echo e(++$i); ?></th>
			<td><?php echo e($blog->title); ?></td>
			<td><?php echo e($blog->content); ?></td>
			<td>
				<?php if($blog->image !=''): ?>
				<img src="<?php echo e(asset('uploads')); ?>/<?php echo e($blog->image); ?>" style="height:100px;width:100px;border-radius:50%;">

				<?php endif; ?>
			</td>
			<td>
				<?php if($blog->user_id == Session::get('userlogin')): ?>
					<a class="btn btn-success" href="<?php echo e(url('blog/edit')); ?>/<?php echo e(encrypt($blog->id)); ?>">Edit</a>
				<?php endif; ?>
			&nbsp;&nbsp;<a class="btn btn-danger" href="<?php echo e(url('blog_delete',encrypt($blog->id))); ?>">Delete</a>
			
		</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php else: ?>
		<tr>
			<td>
				<div class="alert alert-danger">Data not found</div>
			</td>
		</tr>
		<?php endif; ?>
		
		
	  </tbody>
	</table>

	
	</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\greenhonchos_machine_test\resources\views/dashboard.blade.php ENDPATH**/ ?>