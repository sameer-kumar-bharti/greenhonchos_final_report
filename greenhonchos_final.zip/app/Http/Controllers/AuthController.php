<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Hash;
use Session;

class AuthController extends Controller
{
    public function login(){
        return view('login');
    }
    public function signup(){
        return view('signup');
    }

    public function user_signup(Request $request){
        $request->validate([
            'name'=>'required|min:3|max:30',
            'email'=>'required|email|unique:users',
            'password'=>'required|min:5:max:10',
        ]);
        $user = new User;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        if($user->save()){
            return redirect('login')->with('success', 'Registered successfully please login !!');
        }else{
            return redirect()->back()->with('error', 'RSomething wrong!');
        }
    }

    public function login_user(Request $request){
        $request->validate([
            'email'=>'required',
            'password'=>'required|min:5:max:10',
        ]);
        $email = $request->email;
        $password = $request->password;
        $user = User::where('email',$email)->first();
        if($user!=''){
            if($email == $user->email && Hash::check($password,$user->password)){
                Session::put('userlogin',$user->id);
                return redirect('/')->with('success', 'Logged in successfully !!');
            }else{
                return redirect()->back()->with('error', 'Invalid email id or password !!');
            }
        }else{
            return redirect()->back()->with('error', 'User not exist !!');
        }
        
    }

    public function logout(){
        Session::forget('userlogin');
        return redirect('/')->with('success', 'You are Logged out !!');
    }
}
