
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--============ Blog ============-->
<div class=" mb-3" style="margin-top:20px;">
		  <img class="card-img-top" src="<?php echo e(asset('uploads')); ?>/<?php echo e($single_blog->image); ?>" alt="Card image cap" style="height:300px;width:60%;">
		  <div class="card-body">
			<h5 class="card-title"><?php echo e($single_blog->title); ?></h5>
			<p class="card-text">
                <?php echo e($single_blog->content); ?>

			</p>
			<p class="card-text"><small class="text-muted"><?php echo e(date('d F, Y', strtotime($single_blog->created_at))); ?></small></p>
		  </div>

          <!--comment section-->
            <div class="card">
                <div class="card-header">
                    Comments
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <b>Name:<?php echo e($comment->name); ?></b>
                        <p><?php echo e($comment->comment); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div><br>
            <div class="card" style="width:50%;">
            <div class="card-header">
                Leave comment
            </div>
            <div class="card-body">
            <form method="post" action="<?php echo e(url('comment')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="blog_id" value="<?php echo e($single_blog->id); ?>">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp" placeholder="Enter name">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <textarea name="comment" class="form-control" placeholder="comment"></textarea>
                        </div>
                    </div>
                    
                </div>
                <button type="submit" class="btn btn-primary form-control" style="width:20%;">Submit</button>
                </form>
            </div>
            
            </div>
          <!--\comment section-->
</div>
<!--============ /Blog ============-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\greenhonchos-main (1)\greenhonchos-main\blog\resources\views/single_blog.blade.php ENDPATH**/ ?>