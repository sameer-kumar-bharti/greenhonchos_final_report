

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--main content-->

<div style="margin-top:20px;">
<h5>Blogs</h5><br>
    <div class="row">
        <?php $__currentLoopData = $all_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card bg-light mb-3">
                <div class="card-body">
                <h5 class="card-title"><a href="<?php echo e(url('single_blog',$blog->slug)); ?>"><?php echo e($blog->title); ?></a></h5>
                <p class="card-text"><?php echo e(Str::limit($blog->content, 50)); ?>...</p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!--\main content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\greenhonchos_machine_test\resources\views/index.blade.php ENDPATH**/ ?>