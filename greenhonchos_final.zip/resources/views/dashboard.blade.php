@extends('layout.app')

@section('content')
@include('layout.navbar')
<div class="container" style="margin-top:40px;">
<div class="row">
	
	<div class="col-md-4">
	<form action="{{url('dashboard')}}" method="get">
		<select class="form-control" name="filter">
			<option value="">Author</option>
			@foreach($users as $user)
				<option value="{{$user->id}}">{{$user->name}}</option>
			@endforeach
		</select>
	</div>
	<span><button class="btn btn-primary float-right" type="submit">Search</button></span>
</form>
	<div class="col">
		<a class="btn btn-primary float-right" href="{{url('blog')}}">Add blog</a>
	</div>
</div><br><br>
	
	<table class="table">
	  <thead class="thead-dark">
		<tr>
		  <th scope="col">#</th>
		  <th scope="col">Title</th>
		  <th scope="col">Content</th>
		  <th scope="col">Image</th>
		  <th scope="col" style="width:16%;">Action</th>
		</tr>
	  </thead>
	  <tbody>
		@php
        $i = 0;
		@endphp
		@if(count($blogs) > 0)
			@foreach($blogs as $blog)
			<tr>
			<th scope="row">{{ ++$i}}</th>
			<td>{{$blog->title}}</td>
			<td>{{$blog->content}}</td>
			<td>
				@if($blog->image !='')
				<img src="{{asset('uploads')}}/{{$blog->image}}" style="height:100px;width:100px;border-radius:50%;">

				@endif
			</td>
			<td>
				@if($blog->user_id == Session::get('userlogin'))
					<a class="btn btn-success" href="{{url('blog/edit')}}/{{encrypt($blog->id)}}">Edit</a>
				@endif
			&nbsp;&nbsp;<a class="btn btn-danger" href="{{url('blog_delete',encrypt($blog->id))}}">Delete</a>
			
		</td>
			</tr>
			@endforeach
		@else
		<tr>
			<td>
				<div class="alert alert-danger">Data not found</div>
			</td>
		</tr>
		@endif
		
		
	  </tbody>
	</table>

	
	</div>
    @endsection