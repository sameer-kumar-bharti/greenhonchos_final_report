<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\AuthController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [BlogController::class,'index']);

Route::get('/login', [AuthController::class,'login']);
Route::get('/signup', [AuthController::class,'signup']);
Route::post('/user_signup', [AuthController::class,'user_signup']);
Route::post('/login_user', [AuthController::class,'login_user']);
Route::get('/logout', [AuthController::class,'logout']);
Route::get('/single_blog/{slug}', [BlogController::class,'single_blog']);
Route::post('/comment', [BlogController::class,'comment']); 
Route::group(['middleware' => ['userlogin']], function () {
    Route::get('/dashboard', [BlogController::class,'dashboard']);
    Route::get('/blog', [BlogController::class,'create_blog']);
    Route::post('/store', [BlogController::class,'store']);
    Route::get('/blog/edit/{id}', [BlogController::class,'edit_blog']);
    Route::post('/update', [BlogController::class,'update']);
    Route::get('/blog_delete/{id}', [BlogController::class,'blog_delete']);
});
